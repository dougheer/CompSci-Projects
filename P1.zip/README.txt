Tokenizer README

The dependencies for the code are the java classes java.io.File, java.io.FileWriter, java.io.IOException ,java.io.PrintWriter, java.util.ArrayList,
java.util.HashMap ,java.util.HashSet ,java.util.Map ,java.util.Scanner; ,java.util.Set. These can be dowloned direclty from the java compiler.

To build the code you need the mentioned classes above along some complier that uses the java language as the project was constructed in java.
The code itself is comprised of 2 classes a main method and the tokenizer class.

To run it you put both the main method class and the tokenizer class into a java compiler. Then in the main method you modify
the parameter string in the tokenizer declaration with the location of the file you want tokenize. 
Then you compile and run the code and the output of tokenizer and the words count will be sent to 2 text files.
